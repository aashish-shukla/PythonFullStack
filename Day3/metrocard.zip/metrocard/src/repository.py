from src.model import Station

metroCard = dict()

rates  = {
    "ADULT" :200 ,
    "SENIOR_CITIZEN" : 100 ,
    "KID" :50
}
stations =  {
    "CENTRAL" :  Station("CENTRAL") ,
    "AIRPORT" : Station("AIRPORT")
}
